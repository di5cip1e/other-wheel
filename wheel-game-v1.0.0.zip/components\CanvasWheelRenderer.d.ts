import { Wheel, Wedge } from '../models';
export interface CanvasRenderOptions {
    wheelId: string;
    wheel: Wheel;
    showLabels?: boolean;
    showProbabilityIndicators?: boolean;
    highlightedWedgeId?: string;
    animationProgress?: number;
}
export interface VisualEffect {
    type: 'glow' | 'pulse' | 'sparkle' | 'highlight';
    intensity: number;
    color?: string;
    duration?: number;
}
export interface RenderingMetrics {
    frameTime: number;
    fps: number;
    drawCalls: number;
    lastRenderTime: number;
}
export declare class CanvasWheelRenderer {
    private canvas;
    private ctx;
    private container;
    private needleElement;
    private animationFrameId;
    private metrics;
    private activeEffects;
    private wheelRotations;
    private wheelVelocities;
    private imageCache;
    private isDirty;
    constructor(containerId: string);
    private initializeCanvas;
    private initializeNeedle;
    renderWheel(options: CanvasRenderOptions): void;
    private calculateWedgeAngles;
    private renderWedge;
    private renderWedgeLabel;
    private renderWedgeMedia;
    private renderWheelBorder;
    private applyVisualEffects;
    private applyGlowEffect;
    private applyPulseEffect;
    private applySparkleEffect;
    private applyHighlightEffect;
    updateWheelRotation(wheelId: string, angle: number, velocity?: number): void;
    addVisualEffect(wheelId: string, effect: VisualEffect): void;
    clearVisualEffects(wheelId: string): void;
    startAnimationLoop(): void;
    stopAnimationLoop(): void;
    determineWedgeResult(_wheelId: string, angle: number, wedges: Wedge[]): {
        index: number;
        wedge: Wedge;
    };
    getMetrics(): RenderingMetrics;
    clear(): void;
    getCanvas(): HTMLCanvasElement;
    getContainer(): HTMLElement;
    private getOrLoadImage;
    private lightenColor;
    private updateFPS;
    private hasActiveAnimations;
}
//# sourceMappingURL=CanvasWheelRenderer.d.ts.map