import { WedgeMedia } from '../models';
export interface MediaLoadResult {
    success: boolean;
    element?: HTMLImageElement | HTMLVideoElement;
    error?: string;
    fallbackUsed: boolean;
}
export interface MediaValidationResult {
    isValid: boolean;
    error?: string;
    suggestedType?: 'image' | 'video' | 'text';
}
export interface MediaCacheEntry {
    element: HTMLImageElement | HTMLVideoElement;
    loadedAt: number;
    size: number;
}
export declare class MediaManager {
    private cache;
    private loadingPromises;
    private readonly maxCacheSize;
    private readonly supportedImageTypes;
    private readonly supportedVideoTypes;
    private readonly maxFileSize;
    loadMedia(media: WedgeMedia): Promise<MediaLoadResult>;
    validateMedia(media: WedgeMedia): MediaValidationResult;
    getSupportedTypes(): {
        images: string[];
        videos: string[];
    };
    createMediaFromFile(file: File): Promise<WedgeMedia>;
    clearCache(): void;
    getCacheStats(): {
        entries: number;
        estimatedSize: number;
    };
    private performLoad;
    private loadImage;
    private loadVideo;
    private addToCache;
    private ensureCacheSpace;
    private validateDataUrl;
    private isLikelyImageUrl;
    private isLikelyVideoUrl;
    private guessTypeFromUrl;
    private fileToDataUrl;
}
export declare const mediaManager: MediaManager;
//# sourceMappingURL=MediaManager.d.ts.map