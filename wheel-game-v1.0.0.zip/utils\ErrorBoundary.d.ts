import { GameError } from './ErrorHandler';
export interface ErrorBoundaryOptions {
    componentName: string;
    fallbackContent?: string | HTMLElement;
    onError?: (error: GameError) => void;
    onRecover?: () => void;
    autoRecover?: boolean;
    maxRetries?: number;
}
export declare class ErrorBoundary {
    private element;
    private options;
    private retryCount;
    private isErrorState;
    private originalContent;
    constructor(element: HTMLElement, options: ErrorBoundaryOptions);
    wrapFunction<T extends any[], R>(fn: (...args: T) => R, context?: any): (...args: T) => R | null;
    wrapAsyncFunction<T extends any[], R>(fn: (...args: T) => Promise<R>, context?: any): (...args: T) => Promise<R | null>;
    handleError(error: any): void;
    attemptRecovery(): Promise<boolean>;
    reset(): void;
    isInErrorState(): boolean;
    getRetryCount(): number;
    private setupErrorHandling;
    private convertToGameError;
    private showFallbackContent;
    private createDefaultFallbackContent;
}
export declare class ComponentErrorManager {
    private boundaries;
    private static instance;
    private constructor();
    static getInstance(): ComponentErrorManager;
    createBoundary(element: HTMLElement, options: ErrorBoundaryOptions): ErrorBoundary;
    getBoundary(componentName: string): ErrorBoundary | undefined;
    removeBoundary(componentName: string): void;
    resetAllBoundaries(): void;
    getErrorStatistics(): {
        [componentName: string]: {
            retryCount: number;
            isInError: boolean;
        };
    };
    private setupGlobalErrorHandling;
}
export declare function withErrorBoundary(componentName: string): <T extends {
    new (...args: any[]): {};
}>(constructor: T) => {
    new (...args: any[]): {};
} & T;
export declare const componentErrorManager: ComponentErrorManager;
//# sourceMappingURL=ErrorBoundary.d.ts.map