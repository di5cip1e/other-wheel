import { GameError, RecoveryOption } from '../utils/ErrorHandler';
export interface NotificationOptions {
    duration?: number;
    showRecoveryOptions?: boolean;
    position?: 'top' | 'bottom' | 'center';
    type?: 'error' | 'warning' | 'info' | 'success';
}
export declare class ErrorNotification {
    private container;
    private notifications;
    private static instance;
    private constructor();
    static getInstance(): ErrorNotification;
    showError(error: GameError, recoveryOptions?: RecoveryOption[], options?: NotificationOptions): string;
    showSuccess(message: string, options?: NotificationOptions): string;
    showWarning(message: string, options?: NotificationOptions): string;
    dismissNotification(notificationId: string): void;
    dismissAll(): void;
    getActiveCount(): number;
    private createContainer;
    private createNotification;
    private createRecoverySection;
    private getIconForType;
    private getNotificationTypeFromSeverity;
    private getDefaultDuration;
    private escapeHtml;
}
export declare const errorNotification: ErrorNotification;
//# sourceMappingURL=ErrorNotification.d.ts.map