import { Rule, RuleEvaluationContext, RuleEvaluationResult, RuleValidationError, RuleConflict } from '../models/Rule';
export declare class RuleEngine {
    private rules;
    addRule(rule: Rule): void;
    removeRule(ruleId: string): boolean;
    updateRule(rule: Rule): void;
    getAllRules(): Rule[];
    getActiveRules(): Rule[];
    evaluateRules(context: RuleEvaluationContext): RuleEvaluationResult[];
    private evaluateRule;
    private evaluateCondition;
    private evaluateSpecificWedge;
    private evaluateWedgeCombination;
    private evaluateScoreThreshold;
    private evaluateConsecutiveWins;
    private evaluateAvoidWedge;
    private combineConditionResults;
    validateRule(rule: Rule): RuleValidationError[];
    private validateCondition;
    detectConflicts(): RuleConflict[];
    private rulesHaveOverlappingConditions;
    clearRules(): void;
    getRule(ruleId: string): Rule | undefined;
}
//# sourceMappingURL=RuleEngine.d.ts.map