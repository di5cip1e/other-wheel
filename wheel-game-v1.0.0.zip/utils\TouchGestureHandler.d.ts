export interface TouchGestureOptions {
    element: HTMLElement;
    onSwipe?: (direction: SwipeDirection, velocity: number) => void;
    onTap?: (x: number, y: number) => void;
    onLongPress?: (x: number, y: number) => void;
    onPinch?: (scale: number, center: {
        x: number;
        y: number;
    }) => void;
    swipeThreshold?: number;
    longPressDelay?: number;
    preventDefault?: boolean;
}
export declare enum SwipeDirection {
    Up = "up",
    Down = "down",
    Left = "left",
    Right = "right",
    Clockwise = "clockwise",
    CounterClockwise = "counterclockwise"
}
export declare class TouchGestureHandler {
    private element;
    private options;
    private touchStart;
    private touchHistory;
    private longPressTimer;
    private isLongPress;
    private initialPinchDistance;
    constructor(options: TouchGestureOptions);
    private bindEvents;
    private handleTouchStart;
    private handleTouchMove;
    private handleTouchEnd;
    private handleTouchCancel;
    private handleMouseDown;
    private handleMouseMove;
    private handleMouseUp;
    private handleMouseLeave;
    private startLongPressTimer;
    private clearLongPressTimer;
    private calculateVelocity;
    private getSwipeDirection;
    private isCircularMotion;
    private getDistance;
    private getCenter;
    private reset;
    dispose(): void;
}
//# sourceMappingURL=TouchGestureHandler.d.ts.map