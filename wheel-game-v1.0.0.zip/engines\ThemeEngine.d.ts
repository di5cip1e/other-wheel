export interface ColorPalette {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    surface: string;
    text: string;
    textSecondary: string;
    border: string;
    success: string;
    warning: string;
    error: string;
    info: string;
}
export interface Typography {
    fontFamily: string;
    fontSize: {
        xs: string;
        sm: string;
        base: string;
        lg: string;
        xl: string;
        '2xl': string;
        '3xl': string;
    };
    fontWeight: {
        light: number;
        normal: number;
        medium: number;
        semibold: number;
        bold: number;
    };
    lineHeight: {
        tight: number;
        normal: number;
        relaxed: number;
    };
}
export interface Spacing {
    xs: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
    '2xl': string;
    '3xl': string;
}
export interface BorderRadius {
    none: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
    full: string;
}
export interface Shadows {
    sm: string;
    md: string;
    lg: string;
    xl: string;
}
export interface Animations {
    duration: {
        fast: string;
        normal: string;
        slow: string;
    };
    easing: {
        linear: string;
        easeIn: string;
        easeOut: string;
        easeInOut: string;
    };
}
export interface VisualTheme {
    id: string;
    name: string;
    description?: string;
    colors: ColorPalette;
    typography: Typography;
    spacing: Spacing;
    borderRadius: BorderRadius;
    shadows: Shadows;
    animations: Animations;
    customProperties?: Record<string, string>;
}
export interface ThemeConfig {
    currentThemeId: string;
    customThemes: VisualTheme[];
    enableAnimations: boolean;
    reducedMotion: boolean;
}
export declare class ThemeEngine {
    private config;
    private currentTheme;
    private styleElement;
    private observers;
    private builtInThemes;
    constructor(config?: ThemeConfig);
    private getDefaultConfig;
    private initializeBuiltInThemes;
    private createStyleElement;
    loadTheme(themeId: string): boolean;
    getTheme(themeId: string): VisualTheme | null;
    private applyTheme;
    private generateCSSVariables;
    private generateComponentStyles;
    addCustomTheme(theme: VisualTheme): void;
    removeCustomTheme(themeId: string): boolean;
    getAllThemes(): VisualTheme[];
    getCurrentTheme(): VisualTheme | null;
    setAnimationsEnabled(enabled: boolean): void;
    setReducedMotion(reduced: boolean): void;
    subscribe(callback: (theme: VisualTheme) => void): () => void;
    private notifyObservers;
    getConfig(): ThemeConfig;
    exportTheme(themeId: string): string | null;
    importTheme(themeJson: string): boolean;
    private validateTheme;
    dispose(): void;
}
//# sourceMappingURL=ThemeEngine.d.ts.map