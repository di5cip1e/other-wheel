import { GameError } from './ErrorHandler';
export interface GameStateBackup {
    timestamp: number;
    gameState: any;
    checksum: string;
}
export declare class GameStateRecovery {
    private static readonly MAX_BACKUPS;
    private static readonly BACKUP_KEY;
    private backups;
    constructor();
    createBackup(gameState: any): void;
    restoreFromBackup(): any | null;
    getAvailableBackups(): GameStateBackup[];
    validateGameState(gameState: any): boolean;
    repairGameState(gameState: any): any;
    private validateBackup;
    private validateWheel;
    private repairWheel;
    private createDefaultWheels;
    private createDefaultWedges;
    private createDefaultSettings;
    private createMinimalGameState;
    private getDefaultColor;
    private calculateChecksum;
    private loadBackups;
    private saveBackups;
}
export declare class FeatureDegradation {
    private static readonly DEGRADATION_KEY;
    private degradedFeatures;
    constructor();
    enableDegradation(feature: string, reason?: string): void;
    disableDegradation(feature: string): void;
    isFeatureDegraded(feature: string): boolean;
    getDegradedFeatures(): string[];
    clearAllDegradations(): void;
    private loadDegradationState;
    private saveDegradationState;
}
export declare class AutoRecoveryCoordinator {
    private gameStateRecovery;
    private featureDegradation;
    constructor();
    attemptFullRecovery(error: GameError, currentGameState?: any): Promise<boolean>;
    private recoverGameState;
    private recoverPhysics;
    private recoverRendering;
    private recoverStorage;
    private recoverMedia;
    private recoverGeneric;
    private setupRecoveryStrategies;
    getGameStateRecovery(): GameStateRecovery;
    getFeatureDegradation(): FeatureDegradation;
}
export declare const gameStateRecovery: GameStateRecovery;
export declare const featureDegradation: FeatureDegradation;
export declare const autoRecoveryCoordinator: AutoRecoveryCoordinator;
//# sourceMappingURL=ErrorRecovery.d.ts.map