import { AudioEngine, AudioTheme } from '../engines/AudioEngine';
import { ThemeEngine } from '../engines/ThemeEngine';
export interface ThemeControlsConfig {
    showVolumeControls: boolean;
    showThemeSelector: boolean;
    showAudioToggle: boolean;
    showAnimationToggle: boolean;
    compact: boolean;
}
export declare class ThemeControls {
    private container;
    private audioEngine;
    private themeEngine;
    private config;
    private audioThemes;
    constructor(container: HTMLElement, audioEngine: AudioEngine, themeEngine: ThemeEngine, config?: ThemeControlsConfig);
    private getDefaultConfig;
    private initializeAudioThemes;
    private render;
    private attachEventListeners;
    private updateVolumeDisplay;
    private playButtonClickSound;
    private testAudio;
    private resetToDefaults;
    refresh(): void;
    getConfig(): ThemeControlsConfig;
    updateConfig(config: Partial<ThemeControlsConfig>): void;
    addAudioTheme(theme: AudioTheme): void;
    removeAudioTheme(themeId: string): void;
    dispose(): void;
}
//# sourceMappingURL=ThemeControls.d.ts.map