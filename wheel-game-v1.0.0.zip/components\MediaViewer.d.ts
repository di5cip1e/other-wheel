import { WedgeMedia } from '../models';
export interface MediaViewerOptions {
    maxWidth?: number;
    maxHeight?: number;
    showControls?: boolean;
    autoplay?: boolean;
    fallbackText?: string;
    className?: string;
}
export declare class MediaViewer {
    private container;
    private currentMedia;
    private currentElement;
    private options;
    constructor(container: HTMLElement, options?: MediaViewerOptions);
    displayMedia(media: WedgeMedia | null, fallbackText?: string): Promise<void>;
    clear(): void;
    updateOptions(options: Partial<MediaViewerOptions>): void;
    getCurrentMedia(): WedgeMedia | null;
    hasMedia(): boolean;
    private setupContainer;
    private clearContent;
    private showLoading;
    private showMediaElement;
    private showImage;
    private showVideo;
    private showFallback;
    private applyImageSizeConstraints;
    private applyVideoSizeConstraints;
}
export declare function createMediaViewer(container: HTMLElement, options?: MediaViewerOptions): MediaViewer;
export declare function displayMediaTemporary(media: WedgeMedia, parentElement: HTMLElement, options?: MediaViewerOptions & {
    duration?: number;
}): Promise<void>;
//# sourceMappingURL=MediaViewer.d.ts.map