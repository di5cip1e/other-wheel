export interface PhysicsState {
    angle: number;
    angularVelocity: number;
    angularAcceleration: number;
    momentOfInertia: number;
}
export interface WheelPhysicsConfig {
    momentOfInertia: number;
    frictionCoefficient: number;
    clutchRatio?: number;
}
export interface PhysicsEngineConfig {
    timeStep: number;
    maxIterations: number;
    stabilityThreshold: number;
}
export declare class PhysicsEngine {
    private wheels;
    private wheelConfigs;
    private clutchConnections;
    private config;
    private accumulatedTime;
    constructor(config?: Partial<PhysicsEngineConfig>);
    addWheel(wheelId: string, config: WheelPhysicsConfig, initialState?: Partial<PhysicsState>): void;
    removeWheel(wheelId: string): void;
    setClutchConnection(outerWheelId: string, innerWheelId: string): void;
    applyTorque(wheelId: string, torque: number): void;
    stepSimulation(deltaTime: number): void;
    private performPhysicsStep;
    private applyFriction;
    private applyClutchTorques;
    private normalizeAngle;
    isStable(): boolean;
    getWheelState(wheelId: string): PhysicsState | null;
    getAllWheelStates(): Map<string, PhysicsState>;
    reset(): void;
    setWheelVelocity(wheelId: string, angularVelocity: number): void;
    getConfig(): PhysicsEngineConfig;
    updateConfig(newConfig: Partial<PhysicsEngineConfig>): void;
}
//# sourceMappingURL=PhysicsEngine.d.ts.map