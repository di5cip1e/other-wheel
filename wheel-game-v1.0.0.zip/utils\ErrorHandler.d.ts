export declare enum ErrorType {
    PHYSICS = "physics",
    MEDIA = "media",
    VALIDATION = "validation",
    STORAGE = "storage",
    NETWORK = "network",
    RENDERING = "rendering",
    AUDIO = "audio",
    GAME_STATE = "game_state",
    UNKNOWN = "unknown"
}
export declare enum ErrorSeverity {
    LOW = "low",
    MEDIUM = "medium",
    HIGH = "high",
    CRITICAL = "critical"
}
export interface GameError extends Error {
    type: ErrorType;
    severity: ErrorSeverity;
    code: string;
    context?: Record<string, any>;
    timestamp: number;
    recoverable: boolean;
    userMessage: string;
    technicalMessage: string;
}
export interface RecoveryOption {
    id: string;
    label: string;
    description: string;
    action: () => Promise<boolean>;
    automatic?: boolean;
}
export interface ErrorReport {
    error: GameError;
    userAgent: string;
    url: string;
    gameState?: any;
    stackTrace: string;
    timestamp: number;
}
export declare class GameErrorFactory {
    static createPhysicsError(message: string, code: string, context?: Record<string, any>): GameError;
    static createMediaError(message: string, code: string, context?: Record<string, any>): GameError;
    static createValidationError(message: string, code: string, context?: Record<string, any>): GameError;
    static createStorageError(message: string, code: string, context?: Record<string, any>): GameError;
    static createRenderingError(message: string, code: string, context?: Record<string, any>): GameError;
    static createGameStateError(message: string, code: string, context?: Record<string, any>): GameError;
    private static createError;
}
export declare class ErrorHandler {
    private static instance;
    private errorLog;
    private recoveryStrategies;
    private degradationFlags;
    private onErrorCallback?;
    private onRecoveryCallback?;
    private constructor();
    static getInstance(): ErrorHandler;
    setErrorCallback(callback: (error: GameError) => void): void;
    setRecoveryCallback(callback: (error: GameError, success: boolean) => void): void;
    handleError(error: GameError): Promise<boolean>;
    getRecoveryOptions(error: GameError): RecoveryOption[];
    private attemptRecovery;
    enableDegradation(feature: string): void;
    isFeatureDegraded(feature: string): boolean;
    getErrorHistory(): GameError[];
    clearErrorHistory(): void;
    generateErrorReport(error: GameError, gameState?: any): ErrorReport;
    private logError;
    private initializeRecoveryStrategies;
    private setupGlobalErrorHandling;
}
export declare const errorHandler: ErrorHandler;
//# sourceMappingURL=ErrorHandler.d.ts.map