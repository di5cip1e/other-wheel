import { Preset, PresetValidationResult, GameState } from '../models';
export declare class PresetManager {
    private static readonly STORAGE_KEY;
    private static readonly EXPORT_VERSION;
    private static readonly MAX_PRESETS;
    savePreset(preset: Preset): Promise<void>;
    loadPreset(id: string): Promise<Preset | null>;
    getAllPresets(): Promise<Preset[]>;
    deletePreset(id: string): Promise<boolean>;
    createPresetFromGameState(gameState: GameState, name: string, description?: string): Preset;
    applyPresetToGameState(preset: Preset, currentPlayers?: any[]): GameState;
    exportPreset(preset: Preset): string;
    importPreset(jsonString: string): Preset;
    validatePreset(preset: any): PresetValidationResult;
    checkStorageAvailability(): {
        available: boolean;
        error?: string;
    };
    getStorageInfo(): {
        used: number;
        total: number;
        presetCount: number;
    };
    private wheelToConfig;
    private configToWheel;
    private generateId;
}
//# sourceMappingURL=PresetManager.d.ts.map