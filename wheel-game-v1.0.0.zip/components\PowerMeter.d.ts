import { PowerMeterState } from '../models/index.js';
export interface PowerMeterOptions {
    containerId: string;
    width?: number;
    height?: number;
    oscillationSpeed?: number;
    oscillationPattern?: 'linear' | 'sine' | 'triangle' | 'sawtooth';
    minAngularVelocity?: number;
    maxAngularVelocity?: number;
    showTimingFeedback?: boolean;
    powerCurve?: 'linear' | 'quadratic' | 'cubic';
}
export interface PowerMeterCallbacks {
    onStart?: () => void;
    onStop?: (power: number, angularVelocity: number, timingAccuracy: number) => void;
    onTick?: () => void;
}
export interface TimingFeedback {
    accuracy: number;
    zone: 'poor' | 'good' | 'excellent' | 'perfect';
    color: string;
}
export declare class PowerMeter {
    private container;
    private meterContainer;
    private indicator;
    private button;
    private feedbackDisplay;
    private powerDisplay;
    private state;
    private animationFrame;
    private callbacks;
    private options;
    private startTime;
    private lastTickTime;
    constructor(options: PowerMeterOptions, callbacks?: PowerMeterCallbacks);
    private initializePowerMeter;
    private createPowerZones;
    private handleButtonClick;
    startMeter(): void;
    private animate;
    private detectTicks;
    private calculateOscillationValue;
    stopMeter(): void;
    powerToAngularVelocity(power: number): number;
    private calculateTimingFeedback;
    private displayTimingFeedback;
    resetMeter(): void;
    private updateIndicatorPosition;
    private updatePowerDisplay;
    getCurrentPower(): number;
    getState(): PowerMeterState;
    isActive(): boolean;
    getTimingFeedback(): TimingFeedback;
    setOscillationSpeed(speed: number): void;
    setOscillationPattern(pattern: PowerMeterOptions['oscillationPattern']): void;
    setPowerCurve(curve: PowerMeterOptions['powerCurve']): void;
    destroy(): void;
}
//# sourceMappingURL=PowerMeter.d.ts.map