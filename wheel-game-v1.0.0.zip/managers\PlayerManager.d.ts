import { Player } from '../models';
import { RuleSpinResult } from '../models/Rule';
export interface PlayerScore {
    playerId: string;
    score: number;
    roundsPlayed: number;
    lastResult?: string;
}
export interface TurnResult {
    playerId: string;
    result: string;
    score: number;
    timestamp: number;
}
export declare class PlayerManager {
    private players;
    private scores;
    private currentPlayerIndex;
    private turnHistory;
    private roundNumber;
    constructor();
    addPlayer(name: string, avatarUrl?: string): Player;
    removePlayer(playerId: string): boolean;
    getPlayers(): Player[];
    getCurrentPlayer(): Player | null;
    nextTurn(): Player | null;
    recordTurnResult(result: string, scoreChange?: number): TurnResult;
    getPlayerScores(): PlayerScore[];
    getPlayerScore(playerId: string): PlayerScore | null;
    getPlayerScoreValue(playerId: string): number;
    getTurnHistory(): TurnResult[];
    getGameHistory(): RuleSpinResult[];
    getCurrentRound(): number;
    shouldGameEnd(settings: {
        roundLimit?: number;
        scoreLimit?: number;
    }): boolean;
    getWinners(): Player[];
    reset(): void;
    exportState(): any;
    importState(state: any): void;
    private updateActivePlayer;
}
//# sourceMappingURL=PlayerManager.d.ts.map