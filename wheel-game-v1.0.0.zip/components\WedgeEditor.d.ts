import { Wedge, WedgeMedia } from '../models';
import { MediaValidationResult as MediaManagerValidationResult } from '../managers/MediaManager';
export interface WedgeEditorOptions {
    containerId: string;
    wedge?: Wedge;
    showMediaOptions?: boolean;
}
export interface WedgeEditorCallbacks {
    onWedgeUpdate?: (wedge: Wedge) => void;
    onMediaUpload?: (file: File) => Promise<string>;
    onMediaValidation?: (media: WedgeMedia) => Promise<boolean>;
}
export interface MediaValidationResult {
    isValid: boolean;
    errors: string[];
    warnings: string[];
}
export declare class WedgeEditor {
    private container;
    private wedge;
    private callbacks;
    private options;
    private mediaPreviewContainer;
    constructor(options: WedgeEditorOptions, callbacks?: WedgeEditorCallbacks);
    private createDefaultWedge;
    private initializeEditor;
    private createHeader;
    private createBasicPropertiesSection;
    private createMediaSection;
    private createMediaTypeSelector;
    private createMediaContentInput;
    private updateMediaContentInput;
    private createPreviewSection;
    private createTextInput;
    private createNumberInput;
    private createColorInput;
    private handleFileUpload;
    private handleFileSelected;
    private updateSubtitle;
    private updatePreview;
    private updateMediaPreview;
    private isValidColor;
    private getContrastColor;
    private triggerUpdate;
    getWedge(): Wedge;
    setWedge(wedge: Wedge): void;
    validateWedge(): MediaValidationResult;
    private showMessage;
    getSupportedMediaTypes(): {
        images: string[];
        videos: string[];
    };
    validateMedia(media: WedgeMedia): Promise<MediaManagerValidationResult>;
    destroy(): void;
}
//# sourceMappingURL=WedgeEditor.d.ts.map