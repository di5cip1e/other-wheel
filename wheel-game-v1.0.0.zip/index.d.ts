import './styles/main.css';
//# sourceMappingURL=index.d.ts.map