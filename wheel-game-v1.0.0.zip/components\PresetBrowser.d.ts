import { Preset } from '../models';
export interface PresetBrowserOptions {
    container: HTMLElement;
    onPresetLoad?: (preset: Preset) => void;
    onPresetSave?: (preset: Preset) => void;
    onPresetDelete?: (presetId: string) => void;
    onError?: (error: string) => void;
}
export interface PresetBrowserState {
    presets: Preset[];
    selectedPreset: Preset | null;
    isLoading: boolean;
    searchQuery: string;
    sortBy: 'name' | 'created' | 'modified';
    sortOrder: 'asc' | 'desc';
    showImportDialog: boolean;
    showExportDialog: boolean;
}
export declare class PresetBrowser {
    private container;
    private presetManager;
    private state;
    private options;
    constructor(options: PresetBrowserOptions);
    private initialize;
    private createUI;
    private loadPresets;
    private renderPresetList;
    private getFilteredAndSortedPresets;
    private showPresetDetails;
    private attachEventListeners;
    private attachModalEventListeners;
    private showImportDialog;
    private hideImportDialog;
    private showSaveDialog;
    private hideSaveDialog;
    private validateImportData;
    private performImport;
    private performSave;
    private loadPreset;
    private exportPreset;
    private deletePreset;
    private setLoading;
    private handleError;
    private showSuccessMessage;
    private formatDate;
    private escapeHtml;
    refresh(): Promise<void>;
    getSelectedPreset(): Preset | null;
    selectPreset(presetId: string): void;
    clearSelection(): void;
    getStorageInfo(): {
        used: number;
        total: number;
        presetCount: number;
    };
    destroy(): void;
}
//# sourceMappingURL=PresetBrowser.d.ts.map