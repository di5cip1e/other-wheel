export interface RandomGenerator {
    next(): number;
    nextInt(min: number, max: number): number;
    nextFloat(min: number, max: number): number;
    getSeed(): number;
    setSeed(seed: number): void;
}
export declare class LCGRandom implements RandomGenerator {
    private seed;
    private readonly a;
    private readonly c;
    private readonly m;
    constructor(seed?: number);
    next(): number;
    nextInt(min: number, max: number): number;
    nextFloat(min: number, max: number): number;
    getSeed(): number;
    setSeed(seed: number): void;
}
export declare class WeightedSelector {
    private rng;
    constructor(rng: RandomGenerator);
    select<T>(items: T[], weights: number[]): T;
    selectIndex(weights: number[]): number;
}
export declare class DeterministicRNG {
    private static instance;
    private static selector;
    static initialize(seed: number): void;
    static getInstance(): LCGRandom;
    static getSelector(): WeightedSelector;
    static next(): number;
    static nextInt(min: number, max: number): number;
    static nextFloat(min: number, max: number): number;
    static setSeed(seed: number): void;
    static getSeed(): number;
    static selectWeighted<T>(items: T[], weights: number[]): T;
    static selectWeightedIndex(weights: number[]): number;
}
export declare class StatisticalUtils {
    static testWeightedDistribution(weights: number[], samples?: number, tolerance?: number, seed?: number): {
        passed: boolean;
        results: number[];
        expected: number[];
        deviations: number[];
    };
}
//# sourceMappingURL=RandomUtils.d.ts.map