import { Player } from '../models';
import { PlayerManager } from '../managers/PlayerManager';
export interface PlayerUIConfig {
    showAvatars: boolean;
    showScores: boolean;
    showRoundInfo: boolean;
    maxPlayersDisplayed: number;
}
export declare class PlayerUI {
    private container;
    private playerManager;
    private config;
    private currentPlayerElement;
    private scoreboardElement;
    private roundInfoElement;
    constructor(container: HTMLElement, playerManager: PlayerManager, config?: Partial<PlayerUIConfig>);
    private initialize;
    private createCurrentPlayerDisplay;
    private createScoreboard;
    private createRoundInfo;
    update(): void;
    private updateCurrentPlayer;
    private updateScoreboard;
    private updateRoundInfo;
    showTurnTransition(_previousPlayer: Player | null, currentPlayer: Player | null): void;
    showGameEnd(winners: Player[], ruleMessage?: string): void;
    updateConfig(newConfig: Partial<PlayerUIConfig>): void;
    destroy(): void;
}
//# sourceMappingURL=PlayerUI.d.ts.map