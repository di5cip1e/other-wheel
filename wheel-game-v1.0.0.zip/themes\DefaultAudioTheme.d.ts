import { AudioTheme } from '../engines/AudioEngine';
export declare const defaultAudioTheme: AudioTheme;
export declare const retroAudioTheme: AudioTheme;
export declare const silentAudioTheme: AudioTheme;
//# sourceMappingURL=DefaultAudioTheme.d.ts.map