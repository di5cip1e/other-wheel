export interface AccessibilityOptions {
    announceChanges?: boolean;
    highContrast?: boolean;
    reducedMotion?: boolean;
    keyboardNavigation?: boolean;
    screenReaderOptimizations?: boolean;
}
export interface AriaLiveRegion {
    element: HTMLElement;
    politeness: 'polite' | 'assertive';
    atomic?: boolean;
}
export declare class AccessibilityManager {
    private options;
    private liveRegions;
    private focusHistory;
    private lastAnnouncementTime;
    private announcementQueue;
    private isProcessingQueue;
    constructor(options?: AccessibilityOptions);
    private init;
    private createLiveRegions;
    private setupAccessibilityFeatures;
    private createSkipLinks;
    private setupFocusManagement;
    private addLandmarks;
    private setupKeyboardShortcuts;
    private bindEvents;
    private detectUserPreferences;
    private applyAccessibilityPreferences;
    private trapFocus;
    private announceGameStateChange;
    announce(message: string, priority?: 'polite' | 'assertive'): void;
    private processAnnouncementQueue;
    announceStatus(message: string): void;
    focusElement(elementId: string): void;
    restoreFocus(): void;
    addAriaLabel(element: HTMLElement, label: string): void;
    addAriaDescription(element: HTMLElement, description: string): void;
    setAriaExpanded(element: HTMLElement, expanded: boolean): void;
    setAriaPressed(element: HTMLElement, pressed: boolean): void;
    setAriaSelected(element: HTMLElement, selected: boolean): void;
    addLiveRegion(id: string, politeness?: 'polite' | 'assertive'): HTMLElement;
    updateLiveRegion(id: string, message: string): void;
    enableReducedMotion(enable?: boolean): void;
    enableHighContrast(enable?: boolean): void;
    dispose(): void;
}
//# sourceMappingURL=AccessibilityManager.d.ts.map