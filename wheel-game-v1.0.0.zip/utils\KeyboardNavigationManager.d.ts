export interface KeyboardNavigationOptions {
    rootElement: HTMLElement;
    focusableSelectors?: string[];
    skipLinks?: SkipLink[];
    onFocusChange?: (element: HTMLElement, index: number) => void;
    onActivate?: (element: HTMLElement, event: KeyboardEvent) => void;
    trapFocus?: boolean;
    announceChanges?: boolean;
}
export interface SkipLink {
    text: string;
    targetId: string;
    key?: string;
}
export interface FocusableElement {
    element: HTMLElement;
    index: number;
    group?: string;
}
export declare class KeyboardNavigationManager {
    private rootElement;
    private options;
    private focusableElements;
    private currentFocusIndex;
    private skipLinksContainer;
    private _isKeyboardMode;
    get isKeyboardMode(): boolean;
    private announcer;
    private readonly defaultFocusableSelectors;
    constructor(options: KeyboardNavigationOptions);
    private init;
    private createSkipLinks;
    private createAnnouncer;
    private bindEvents;
    private handleKeyDown;
    private handleKeyUp;
    private handleTabNavigation;
    private handleArrowNavigation;
    private handleActivation;
    private handleEscape;
    private handleHome;
    private handleEnd;
    private handleF6Navigation;
    private handleFocusIn;
    private handleFocusOut;
    private handleMouseDown;
    private addKeyboardModeDetection;
    private updateFocusableElements;
    private isElementFocusable;
    private getElementGroup;
    private getCurrentSection;
    private navigateWheelWedges;
    focusNext(): void;
    focusPrevious(): void;
    focusElement(elementOrId: string | HTMLElement): void;
    focusElementByIndex(index: number): void;
    private announceElement;
    private getElementDescription;
    announce(message: string): void;
    dispose(): void;
}
//# sourceMappingURL=KeyboardNavigationManager.d.ts.map