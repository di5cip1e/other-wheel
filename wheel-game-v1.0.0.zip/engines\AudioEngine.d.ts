export interface AudioConfig {
    masterVolume: number;
    soundEffectsVolume: number;
    musicVolume: number;
    enabled: boolean;
    soundEffectsEnabled: boolean;
    musicEnabled: boolean;
}
export interface SoundEffect {
    id: string;
    name: string;
    url: string;
    volume?: number;
    loop?: boolean;
}
export interface AudioTheme {
    id: string;
    name: string;
    soundEffects: {
        wheelSpin: SoundEffect;
        wheelStop: SoundEffect;
        powerMeterTick: SoundEffect;
        resultReveal: SoundEffect;
        buttonClick: SoundEffect;
        gameStart: SoundEffect;
        gameEnd: SoundEffect;
    };
    backgroundMusic?: SoundEffect;
}
export declare class AudioEngine {
    private config;
    private audioContext;
    private loadedSounds;
    private activeSources;
    private gainNodes;
    private masterGainNode;
    private currentTheme;
    private backgroundMusicSource;
    constructor(config?: AudioConfig);
    private getDefaultConfig;
    private initializeAudioContext;
    loadTheme(theme: AudioTheme): Promise<void>;
    private loadSound;
    playSoundEffect(soundId: string, options?: {
        volume?: number;
        loop?: boolean;
    }): void;
    stopSound(soundId: string): void;
    playBackgroundMusic(): void;
    stopBackgroundMusic(): void;
    stopAllSounds(): void;
    setMasterVolume(volume: number): void;
    setSoundEffectsVolume(volume: number): void;
    setMusicVolume(volume: number): void;
    private updateMasterVolume;
    private updateSoundEffectsVolume;
    private updateMusicVolume;
    setEnabled(enabled: boolean): void;
    setSoundEffectsEnabled(enabled: boolean): void;
    setMusicEnabled(enabled: boolean): void;
    getConfig(): AudioConfig;
    getCurrentTheme(): AudioTheme | null;
    isSupported(): boolean;
    resumeAudioContext(): Promise<void>;
    dispose(): void;
}
//# sourceMappingURL=AudioEngine.d.ts.map