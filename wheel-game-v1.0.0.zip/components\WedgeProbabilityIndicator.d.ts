import { Wedge } from '../models';
export interface ProbabilityIndicatorConfig {
    showPercentages: boolean;
    showRecommendations: boolean;
    highlightMismatches: boolean;
    severityThresholds: {
        low: number;
        medium: number;
        high: number;
    };
}
export interface IndicatorElement {
    element: HTMLElement;
    wedgeId: string;
    update: (wedge: Wedge, allWedges: Wedge[]) => void;
    destroy: () => void;
}
export declare class WedgeProbabilityIndicator {
    private wedgeSelector;
    private config;
    private indicators;
    constructor(config?: Partial<ProbabilityIndicatorConfig>);
    createIndicator(wedge: Wedge, allWedges: Wedge[], container: HTMLElement): IndicatorElement;
    updateAllIndicators(wedges: Wedge[]): void;
    removeIndicator(wedgeId: string): void;
    clearAllIndicators(): void;
    getIndicator(wedgeId: string): IndicatorElement | undefined;
    updateConfig(newConfig: Partial<ProbabilityIndicatorConfig>): void;
    private updateIndicatorContent;
    static generateCSS(): string;
}
export declare function injectProbabilityIndicatorStyles(): void;
export declare function createProbabilityIndicator(config?: Partial<ProbabilityIndicatorConfig>): WedgeProbabilityIndicator;
//# sourceMappingURL=WedgeProbabilityIndicator.d.ts.map