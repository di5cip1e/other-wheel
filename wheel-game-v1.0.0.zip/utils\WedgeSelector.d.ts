import { Wedge } from '../models';
import { RandomGenerator } from './RandomUtils';
export interface WedgeSelectionResult {
    wedge: Wedge;
    index: number;
    probability: number;
}
export interface WeightDistributionAnalysis {
    totalWeight: number;
    probabilities: number[];
    visualAngles: number[];
    probabilityVsVisualDifferences: number[];
    isBalanced: boolean;
    maxDeviation: number;
}
export declare class WedgeSelector {
    private rng;
    constructor(rng?: RandomGenerator);
    selectWedge(wedges: Wedge[]): WedgeSelectionResult;
    selectMultipleWedges(wedgeSets: Wedge[][]): WedgeSelectionResult[];
    analyzeWeightDistribution(wedges: Wedge[]): WeightDistributionAnalysis;
    calculateExpectedProbabilities(wedges: Wedge[]): number[];
    testWeightDistributionAccuracy(wedges: Wedge[], samples?: number, tolerance?: number, seed?: number): {
        passed: boolean;
        actualProbabilities: number[];
        expectedProbabilities: number[];
        deviations: number[];
        maxDeviation: number;
        sampleCount: number;
    };
    generateVisualIndicators(wedges: Wedge[]): Array<{
        wedgeId: string;
        label: string;
        probabilityWeight: number;
        visualWeight: number;
        difference: number;
        severity: 'low' | 'medium' | 'high';
        recommendation: string;
    }>;
    private selectWeightedIndex;
    private validateWeights;
}
export declare function createDeterministicWedgeSelector(seed?: number): WedgeSelector;
export declare function createGlobalWedgeSelector(): WedgeSelector;
//# sourceMappingURL=WedgeSelector.d.ts.map