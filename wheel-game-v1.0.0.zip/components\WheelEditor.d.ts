import { Wheel, Wedge } from '../models';
export interface WheelEditorOptions {
    containerId: string;
    wheel?: Wheel;
    showAdvancedOptions?: boolean;
    enablePreview?: boolean;
}
export interface WheelEditorCallbacks {
    onWedgeAdd?: (wedge: Wedge) => void;
    onWedgeRemove?: (wedgeId: string) => void;
    onWedgeUpdate?: (wedge: Wedge) => void;
    onWheelUpdate?: (wheel: Wheel) => void;
    onPreviewUpdate?: (wheel: Wheel) => void;
}
export interface ValidationResult {
    isValid: boolean;
    errors: string[];
    warnings: string[];
}
export declare class WheelEditor {
    private container;
    private headerContainer;
    private wedgesContainer;
    private advancedContainer;
    private previewContainer;
    private wheel;
    private callbacks;
    private options;
    constructor(options: WheelEditorOptions, callbacks?: WheelEditorCallbacks);
    private createDefaultWheel;
    private initializeEditor;
    private createHeader;
    private createWedgesSection;
    private createAdvancedSection;
    private createPreviewSection;
    private renderWedges;
    private createWedgeElement;
    private createTextInput;
    private createNumberInput;
    private createColorInput;
    private addWedge;
    private removeWedge;
    private generateRandomColor;
    private triggerWedgeUpdate;
    private triggerWheelUpdate;
    private triggerPreviewUpdate;
    private validateWedgeLabel;
    private validateWedgeWeight;
    validateWheel(): ValidationResult;
    getWheel(): Wheel;
    setWheel(wheel: Wheel): void;
    getWedges(): Wedge[];
    addWedgePublic(wedge?: Partial<Wedge>): void;
    removeWedgePublic(wedgeId: string): boolean;
    updateWedgePublic(wedgeId: string, updates: Partial<Wedge>): boolean;
    getWedgeTexts(): string[];
    getWedgeWeights(): number[];
    getWedgeCount(): number;
    updateWedgeText(index: number, text: string): void;
    updateWedgeWeight(index: number, weight: number): void;
    updateAllWedgeTexts(texts: string[]): void;
    updateAllWedgeWeights(weights: number[]): void;
    updateWedgeData(texts: string[], weights: number[]): void;
    destroy(): void;
}
//# sourceMappingURL=WheelEditor.d.ts.map