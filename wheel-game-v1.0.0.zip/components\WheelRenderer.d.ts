import { CanvasWheelRenderer } from './CanvasWheelRenderer';
import { Wheel, Wedge } from '../models';
export interface WheelRenderOptions {
    wheelId: string;
    wedgeCount: number;
    texts: string[];
    colors: string[];
    radius: number;
}
export interface EnhancedWheelRenderOptions {
    wheelId: string;
    wheel: Wheel;
    showLabels?: boolean;
    showProbabilityIndicators?: boolean;
    highlightedWedgeId?: string;
    animationProgress?: number;
    useCanvas?: boolean;
}
export declare class WheelRenderer {
    private container;
    private wheels;
    private needleElement;
    private canvasRenderer;
    private canvasSupported;
    constructor(containerId: string);
    private detectCanvasSupport;
    private initializeContainer;
    private initializeCSSRenderer;
    createWheel(options: WheelRenderOptions): HTMLElement;
    updateWheelRotation(wheelId: string, angle: number): void;
    determineWedgeResult(_wheelId: string, angle: number, wedgeCount: number, texts: string[]): {
        index: number;
        text: string;
    };
    getContainer(): HTMLElement;
    getWheel(wheelId: string): HTMLElement | undefined;
    renderEnhancedWheel(options: EnhancedWheelRenderOptions): void;
    private renderWithCanvas;
    private renderWithCSS;
    updateEnhancedWheelRotation(wheelId: string, angle: number, velocity?: number): void;
    addVisualEffect(wheelId: string, effect: {
        type: 'glow' | 'pulse' | 'sparkle' | 'highlight';
        intensity: number;
        color?: string;
    }): void;
    clearVisualEffects(wheelId: string): void;
    startAnimationLoop(): void;
    stopAnimationLoop(): void;
    getPerformanceMetrics(): {
        frameTime: number;
        fps: number;
        drawCalls: number;
    } | null;
    determineEnhancedWedgeResult(wheelId: string, angle: number, wheel: Wheel): {
        index: number;
        wedge: Wedge;
    };
    isCanvasSupported(): boolean;
    getCanvasRenderer(): CanvasWheelRenderer | null;
    clearWheels(): void;
}
//# sourceMappingURL=WheelRenderer.d.ts.map